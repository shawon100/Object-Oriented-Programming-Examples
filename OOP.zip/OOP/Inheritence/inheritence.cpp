#include <bits/stdc++.h>
using namespace std;
class gcd
{
 int x,y,r,z;
public:
    int gcdx(int a,int b);
};
int gcd::gcdx(int a,int b)
{

    x=a;
    y=b;
    while(y!=0)
    {

        r=x%y;
        x=y;
        y=r;

    }
  return x;
}
class myclass:public gcd
{
    int v,p,mul;
public:
    int lcm(int w,int u);


};
int myclass::lcm(int w,int u)
{
    v=w;
    p=u;
    mul=v*p;
    return (mul/gcdx(v,p));

}

int main()
{
    int m1,m2,i,j,k;
    cin>>m1>>m2;
    myclass ob;
    cout<<"lcm="<<ob.lcm(m1,m2)<<endl;



}
