/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package structlikeclass;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author shuvo
 */
public class Structlikeclass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input =new Scanner(System.in);
        ArrayList<test>my=new ArrayList<test>();
        String x,s;
        double y;
        int n,i,j,t;
       
        result[] a=new result[1000];
        result ob=new result();
        ob.get(a);
        
       
       
           
        
        //t=input.nextInt();
        /*for(i=0;i<t;i++)
        {
            s=input.next();
            n=input.nextInt();
            test a=new test(s,n);
            my.add(a);
        }*/
     
        
        /*for(test ob:my)
        {
            System.out.println("Name="+ob.name+" Roll="+ob.roll);
            i++;
        }*/
     
        
        
        
    }
    
}
