/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package structlikeclass;

/**
 *
 * @author shuvo
 */
import java.util.*;
public class test {
    String name,s2;
    int roll,r;
    public test(String s1, int n1)
    {
        
        this.name=s1;
        this.roll=n1;
    }
   
    
}
