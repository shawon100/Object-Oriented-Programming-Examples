/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritence;

/**
 *
 * @author shuvo
 */
public class myclass extends gcd {
    int v,p,mul;
    int lcm (int w,int u)
    {
        v=w;
        p=u;
        mul=v*p;
        
        return (mul/gcdx(v,p));
    }
}
