/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritence;

/**
 *
 * @author shuvo
 */
import java.util.*;
public class Inheritence {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int m1,m2;
        Scanner input=new Scanner(System.in);
        m1=input.nextInt();
        m2=input.nextInt();
        myclass ob=new myclass();
        System.out.println("lcm="+ob.lcm(m1, m2));
    }
    
    
}
