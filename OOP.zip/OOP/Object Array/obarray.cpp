#include <bits/stdc++.h>
using namespace std;
class samp
{
    int a;
public:
    int setarray(int n);
    int print();
};
int samp::setarray(int n)
{
    a=n;
}
int samp::print()
{
    return a;
}
int main()
{
    samp ob[5];
    int i,j;
    for(i=1;i<=5;i++)
    {
        ob[i].setarray(i);
    }
    for(i=1;i<=5;i++)
    {
        cout<<ob[i].print()<<endl;
    }

    return 0;

}
