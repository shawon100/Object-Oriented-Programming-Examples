#include <bits/stdc++.h>
using namespace std;
class samp
{
    int a,b,c;
public:
    samp(int n);
    int print();

};
samp::samp(int n)
{
    a=n;
}
int samp::print()
{
    return a;
}
int main()
{
    samp ob[5]={1,2,3,4,5};
    int i,j,m;
    double p;
    for(i=0;i<5;i++)
    {
        cout<<ob[i].print()<<endl;
    }
}
