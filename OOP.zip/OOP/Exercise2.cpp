#include<bits/stdc++.h>
using namespace std;
class info
{
    string name,address;
public:
    void store(string n,string a);
    void display();
};

void info::store(string n,string a)
{
    name=n;
    address=a;
}
void info::display()
{
    cout<<"Name="<<name<<endl;
    cout<<"Address="<<address<<endl;
}
int main()
{
    info ob1;
    string a,b;
    cin>>a>>b;
    ob1.store(a,b);
    ob1.display();

    return 0;


}
