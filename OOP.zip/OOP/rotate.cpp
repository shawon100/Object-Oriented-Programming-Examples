#include <bits/stdc++.h>
using namespace std;
class overload
{
    int x,y;
public:
    int rotate(int a);
    long rotate(long a);
};
int overload::rotate(int a)
{
    x=a;
    x=x<<1;
    cout<<x<<endl;
}
long overload::rotate(long a)
{
    y=a;
    y=y<<1;
    cout<<x<<endl;
}

int main()
{
    overload ob1;
    ob1.rotate(10);
    ob1.rotate(100000);

    return 0;
}
