#include <bits/stdc++.h>
using namespace std;
class result
{
    string x;
    double y;
public:
    void get(string s, double z)
    {
        this.x=s;
        this.y=z;
    }
};
int main()
{

}
