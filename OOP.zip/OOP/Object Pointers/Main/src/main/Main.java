/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author shawon10
 */





public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner input =new Scanner(System.in);
        
        String x,s;
        double y;
        int n,i,j,t;
       
        result[] a=new result[1000];
        result ob=new result();
        ob.get(a);
        
    }
    
    
}
class result {
    String x,s,st;
    double y,t;
    public int get(result[] a)
    {
        int n,i,j;
        Scanner input=new Scanner(System.in);
        n=input.nextInt();
        for(i=0;i<n;i++)
        {
           a[i]=new result();//object array should be initialized by constructor
           a[i].x= input.next();
           
           a[i].y=input.nextDouble();
           
        }
       
       
        for(i=0;i<n;i++)
        {
            for(j=i+1;j<n;j++)
            {
                if(a[i].y<a[j].y)
                {
                    t=a[i].y;
                    st=a[i].x;
                    a[i].y=a[j].y;
                    a[i].x=a[j].x;
                    a[j].y=t;
                    a[j].x=st;
                }
            }
        }
        
         /*for(i=0;i<n;i++)
        {
            System.out.println("Name="+a[i].x+"CGPA="+a[i].y);
        }*/
        //sort if same
         
        for(i=0;i<n;i++)
        {
            for(j=i+1;j<n;j++)
            {
                if(a[i].y==a[j].y)
                {
                    if(a[i].x.compareTo(a[j].x)>0)
                    {
                        s=a[i].x;
                        a[i].x=a[j].x;
                        a[j].x=s;
                    }
                        
                }
            }
        }
        double cg=0.0;
        int c=0;
        for(i=0;i<n;i++)
        {
            if(a[i].y>cg || a[i].y<cg)
            {
                c++;
            }
            cg=a[i].y;
            System.out.println(c+"."+a[i].x);
        }
           
        return 0;
    }
}
