#include <bits/stdc++.h>
using namespace std;
int main()

{
    long long int t,a,b,i;
    cin>>t;
    for(i=1;i<=t;i++)
    {
        cin>>a>>b;
        cout<<a+b<<endl;
    }
    return 0;
}
