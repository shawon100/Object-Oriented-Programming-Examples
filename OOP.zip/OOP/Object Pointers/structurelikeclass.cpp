#include <bits/stdc++.h>
using namespace std;
class result
{
    string x;
    double y;
public:
    int get(result a[1000]);
};

int result::get(result a[1000])
{
    int i,j,n;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>a[i].x>>a[i].y;

    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(a[i].y<a[j].y)
            {
                swap(a[i].x,a[j].x);
                swap(a[i].y,a[j].y);
            }
        }
    }
    //sort name
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(a[i].y==a[j].y)
            {
                if(a[i].x>a[j].x)
                {
                    swap(a[i].x,a[j].x);
                }

            }
        }
    }
    double cg=0.0;
    int c=0;
    for(i=0;i<n;i++)
    {

       if(a[i].y>cg || a[i].y<cg)
       {
           c++;
       }
       cg=a[i].y;
       cout<<c<<"."<<a[i].x<<endl;


    }

}

int main()
{
    result a[1000],ob;
    ob.get(a);


}
