#include <bits/stdc++.h>
using namespace std;
class myclass
{
    int i,j;
public:
    myclass(int a);
    int get();
};
myclass::myclass(int a)
{
    i=a;
}
int myclass::get()
{
    return i;
}
int main()
{
    int x;
    cin>>x;
    myclass ob(x);
    myclass *p;
    p=&ob;
    cout<<p->get()<<endl;
    return 0;
}
