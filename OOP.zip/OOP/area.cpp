#include <bits/stdc++.h>
#include <iostream>
using namespace std;

class area
{
    int width,height;
public:
    void take(int w,int h);
    int show();
};

void area::take(int w,int h)
{
    width=w;
    height=h;
}
int area::show()
{
    return (width*height);
}

int main()
{
    area ob;
    ob.take(10,20);
    cout<<ob.show()<<endl;
    return 0;
}
