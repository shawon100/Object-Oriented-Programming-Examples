#include <bits/stdc++.h>
#include<iostream>
using namespace std;

class shawon
{
    int a; //default private
public:
    void f1(int b);
    int f2();
};

void shawon::f1(int b)
{
    a=b;
}
int shawon::f2()
{
    return a;
}

int main()
{
    shawon ob1,ob2;
    ob1.f1(10);
    ob2.f1(20);

    cout<<ob1.f2()<<endl;
    cout<<ob2.f2()<<endl;

    return 0;

}



