#include <bits/stdc++.h>
#include <iostream>
using namespace std;
class fo
{
    int a,b,c;
public:
     int sum(int n1,int n2);
     int sum(int x,int y,int z);


};
int fo::sum(int n1,int n2)
{
    a=n1;
    b=n2;

    return (a+b);
}
int fo::sum(int x,int y,int z)
{
    a=x;
    b=y;
    c=z;

    return(a+b+c);
}

int main()
{
    fo ob1,ob2;
    int a,b,c;
    cin>>a>>b>>c;
    cout<<ob1.sum(a,b)<<endl;
    cout<<ob1.sum(a,b,c)<<endl;

    return 0;


}


