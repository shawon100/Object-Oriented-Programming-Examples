#include <bits/stdc++.h>
using namespace std;
class B
{
    int i;
public:
    void take(int n);
    int print();
};
class D:public B
{
    int j;
public:
    void take_j(int n);
    int mul();
};

void B::take(int n)
{
    i=n;
}
int B::print()
{
    return i;
}

void D::take_j(int n)
{
    j=n;
}

int D::mul()
{
    return j*print();
}

int main()
{
    D ob;
    ob.take(10);
    ob.take_j(5);
    cout<<ob.mul()<<endl;
    return 0;
}
