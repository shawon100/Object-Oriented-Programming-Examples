#include <bits/stdc++.h>
using namespace std;

int f1(int a)
{
    cout<<a<<endl;
}

double f1(int a)
{
    cout<<a<<endl;   //ambiguous double and int return type
}

int main()
{
    f1(10);
    f1(10);
}
