/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author shuvo
 */
import java.util.*;

public class elapsed {
    
    
    elapsed()
    {
    
        long start=System.nanoTime();
        for(int i=0; i<1000 ;i++)
        {
           System.out.println(i);
        }
        long end=System.nanoTime();
        long elapsed=(end-start);
        double seconds= (double)elapsed/1000000000.0;
        System.out.println(seconds +" seconds");
   }
    
}
