#include <bits/stdc++.h>
using namespace std;
class timer
{
    int n,i,j;
    clock_t start,end;
public:
    timer();
    ~timer();

};
timer::timer()
{
    start=clock();
    for(i=1;i<=10000;i++)
    {
        cout<<i<<endl;
    }
    cout<<endl;

}
timer::~timer()
{
    end=clock();
    cout<<"Time="<<(double)(end-start)/CLOCKS_PER_SEC<<" Seconds"<<endl;
}
int main()
{
    timer ob;
    return 0;
}

