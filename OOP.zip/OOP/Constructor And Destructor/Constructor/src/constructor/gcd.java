/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package constructor;

/**
 *
 * @author shuvo
 */
public class gcd {
    int x,y,r,z;
    gcd(int a, int b)
    {
        x=a;
        y=b;
        while(y!=0)
        {

            r=x%y;
            x=y;
            y=r;

        }
        System.out.println("GCD= "+x);
    }
    
}
