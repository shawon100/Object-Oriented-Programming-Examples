#include <bits/stdc++.h>
using namespace std;
class gcd
{
 int x,y,r,z;
public:
    gcd(int a,int b);
};
gcd::gcd(int a,int b)
{

    x=a;
    y=b;
    while(y!=0)
    {

        r=x%y;
        x=y;
        y=r;

    }
    cout<<x<<endl;
}
int main()
{
    int p,q;
    cin>>p>>q;
    gcd ob(p,q);
}
